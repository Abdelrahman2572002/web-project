from django.urls import path
from . import views

urlpatterns = [
    path('', views.main_view, name='search'),
    path('search/', views.search, name='searchDep'),
    path('assignDepartment/', views.assign, name='assignDept'),
]