from django.db import models
from addForm.models import Student

# Create your models here.

