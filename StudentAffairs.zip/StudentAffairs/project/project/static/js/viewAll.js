function update(id) {
    x = document.getElementById('' + id)
    console.log(x.innerHTML)
    if (x.innerHTML == "Active")
        document.getElementById('' + id).innerHTML = "Inactive";
    else
        document.getElementById('' + id).innerHTML = "Active";
}

function updateStatus(status, id) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "http://127.0.0.1:8000/View_Students/update/");
    if (document.cookie.indexOf('csrftoken') > -1) {
        var value = document.cookie.split('csrftoken')[1].split('=')[1];
        xhttp.setRequestHeader('X-CSRFToken', value);
    }
    xhttp.send(JSON.stringify({
        'status': status,
        'id': id,
    }));

    update(id)
}